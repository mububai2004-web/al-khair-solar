# Al Khair Solar Energy — ecommerce starter

This project upgrades the existing storefront into a **full-stack starter** with a database, product management, stock, Razorpay checkout, order tracking and a password-protected admin dashboard.

## Included

- `public/index.html` — storefront, product search/categories, cart, customer delivery form, Razorpay Checkout UI, order tracking.
- `public/admin.html` — admin login, dashboard statistics, add/edit/hide products, price and inventory controls, order list and fulfilment-status updates.
- `server.js` — Express API, SQLite persistence, admin session, payment-order creation, server-side payment-signature verification and webhook verification.
- `data/store.db` — created automatically on first start; seeded with the sample catalogue.
- `.env.example` — configuration template. Copy to `.env` and set your own values.

## Requirements

- Node.js 20 or later
- A Razorpay account for online payments (start in Test Mode)
- A host that supports a persistent disk/volume for SQLite, or change the database layer to a managed database before using a host with ephemeral storage

## Run locally

1. Install Node.js 20+.
2. Open a terminal in this project folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Copy `.env.example` to `.env` and set at least:

   ```env
   PORT=3000
   NODE_ENV=development
   BASE_URL=http://localhost:3000
   SESSION_SECRET=use-a-long-random-secret-here
   ADMIN_USERNAME=your-admin-username
   ADMIN_PASSWORD=use-a-long-unique-password
   ```

5. Start the app:

   ```bash
   npm start
   ```

6. Open `http://localhost:3000` for the shop and `http://localhost:3000/admin` for the admin dashboard.

The first start creates the SQLite database and inserts example products. Prices and stock are examples: update them in the dashboard before accepting real orders.

## Configure Razorpay (test first)

1. Create/verify your merchant account directly with Razorpay and enable Test Mode.
2. Generate Test API keys in the Razorpay Dashboard.
3. Put the **Key ID** and **Key Secret** in the server `.env` only:

   ```env
   RAZORPAY_KEY_ID=rzp_test_your_key_id
   RAZORPAY_KEY_SECRET=your_test_key_secret
   RAZORPAY_WEBHOOK_SECRET=make-a-separate-webhook-secret
   ```

4. Restart the server. The storefront will enable payment checkout once valid keys are configured.
5. Configure a Razorpay webhook to `https://YOUR-DOMAIN/api/payments/razorpay-webhook` and subscribe to `payment.captured`, `payment.failed`, and `order.paid` events. Use the exact same webhook secret in `.env`.
6. Make test payments and confirm that the server records `paid`, that stock is reduced once, and that customers can track their orders.
7. Only switch to live keys after your merchant account is approved and you have tested checkout, signature verification, failed payments, refunds/cancellations, shipping, and support processes.

**Never put `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`, `ADMIN_PASSWORD`, or `SESSION_SECRET` in browser JavaScript or a public repository.** The browser receives only the public Razorpay Key ID.

## Admin tasks

- Visit `/admin` and sign in with `ADMIN_USERNAME` and `ADMIN_PASSWORD` from `.env`.
- Add or edit products, set prices in rupees, stock quantities, product category, description, and an HTTPS image URL.
- Set a product price to `0` for “quote only”; those items cannot be paid for online.
- Orders show customer details, payment status, items and tracking code. Only paid orders can be moved through fulfilment statuses.
- Hiding a product removes it from the public catalogue but keeps its historical order references.

## Order tracking

After successful signature verification, the customer sees an order number and tracking code. On the storefront, use **Track order** and enter the order number plus the exact phone number used at checkout. The customer can see payment status and fulfilment status.

## Deploying

Deploy the entire folder to a Node.js host. Set environment variables in the host dashboard; do not upload `.env`. Set `NODE_ENV=production`, a long random `SESSION_SECRET`, admin credentials, Razorpay keys, and the webhook secret. Add HTTPS and configure the Razorpay webhook with your public HTTPS domain.

**Persistence warning:** this starter uses SQLite at `data/store.db` and a local SQLite session store. Your hosting platform must provide a persistent disk mounted at the app's `data` directory. Do not use an ephemeral filesystem for real orders. For multi-instance or production-scale traffic, use a managed PostgreSQL database and a shared session store.

## Before going live checklist

- Replace sample prices and inventory with verified stock and selling prices.
- Use product photos you own or have permission to use.
- Verify the business phone, address, email, GST details (if applicable), shipping regions, delivery charges, returns/refunds, warranty, privacy policy and terms.
- Add order confirmation notifications (email/SMS/WhatsApp) if required; this starter currently shows tracking details in the browser and stores orders in the database.
- Configure backups, monitoring, strong admin credentials, and a persistent disk.
- Complete Razorpay merchant onboarding and test payments before switching to live keys.

## Technical notes

Payment amount is recalculated from the database on the server. Checkout creates a Razorpay order server-side and verifies the returned signature server-side before marking an order paid. The webhook signature uses the raw request body. This is a deployable starter, not a substitute for merchant approval, production security review, tax/legal review, or fulfilment operations.
