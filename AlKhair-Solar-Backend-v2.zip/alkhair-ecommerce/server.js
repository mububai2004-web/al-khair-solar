require('dotenv').config();
const express = require('express');
const path = require('path');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const Database = require('better-sqlite3');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const Razorpay = require('razorpay');

const app = express();
const PORT = Number(process.env.PORT || 3000);
if (process.env.NODE_ENV === 'production') {
  if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) throw new Error('Set SESSION_SECRET to a random value of at least 32 characters in production.');
  if (!process.env.ADMIN_PASSWORD || process.env.ADMIN_PASSWORD.length < 12) throw new Error('Set ADMIN_PASSWORD to a unique password of at least 12 characters in production.');
}
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const fs = require('fs');
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(path.join(DATA_DIR, 'store.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS admins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  price_paise INTEGER NOT NULL CHECK(price_paise >= 0),
  stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0),
  image_url TEXT NOT NULL DEFAULT '',
  icon TEXT NOT NULL DEFAULT '💡',
  tag TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_no TEXT UNIQUE NOT NULL,
  tracking_code TEXT UNIQUE NOT NULL,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL,
  pincode TEXT NOT NULL,
  items_json TEXT NOT NULL,
  total_paise INTEGER NOT NULL,
  payment_status TEXT NOT NULL DEFAULT 'created',
  order_status TEXT NOT NULL DEFAULT 'Awaiting payment',
  razorpay_order_id TEXT,
  razorpay_payment_id TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS webhook_events (
  event_id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

// Seed demo catalogue only when the database is empty. Replace sample prices/stock before launch.
const productCount = db.prepare('SELECT COUNT(*) AS count FROM products').get().count;
if (productCount === 0) {
  const insert = db.prepare(`INSERT INTO products (name,category,description,price_paise,stock,image_url,icon,tag,active)
    VALUES (@name,@category,@description,@price_paise,@stock,@image_url,@icon,@tag,1)`);
  const seed = [
    {name:'Holder Light – Fan Model',category:'Solar Lights',description:'Confirm exact specifications and power source before purchase.',price_paise:35000,stock:10,image_url:'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=800&q=80',icon:'💡',tag:'POPULAR'},
    {name:'Portable Camping Lamp',category:'Solar Lanterns',description:'Portable lamp for camping and emergency use. Confirm runtime and charging method.',price_paise:45000,stock:10,image_url:'https://images.unsplash.com/photo-1504851149312-7a075b496cc7?auto=format&fit=crop&w=800&q=80',icon:'🏕️',tag:'PORTABLE'},
    {name:'Solar Garden Light – 2 Pieces',category:'Solar Lights',description:'Two-piece garden light set. Confirm colour, size and installation details.',price_paise:65000,stock:10,image_url:'https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&w=800&q=80',icon:'🌱',tag:'2 PIECES'},
    {name:'EN3026 Mini Fan',category:'Solar Accessories',description:'Confirm power source, charging method and availability before ordering.',price_paise:29000,stock:10,image_url:'https://images.unsplash.com/photo-1585771724684-38269d6639fd?auto=format&fit=crop&w=800&q=80',icon:'🌀',tag:'MINI FAN'},
    {name:'Solar Wall Light',category:'Solar Lights',description:'Outdoor wall-light option. Confirm brightness, sensor and weather-resistance rating.',price_paise:0,stock:0,image_url:'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=800&q=80',icon:'🏡',tag:'ASK FOR PRICE'},
    {name:'Solar Street Light',category:'Solar Lights',description:'Ask for a quotation based on wattage, quantity and delivery location.',price_paise:0,stock:0,image_url:'https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&w=800&q=80',icon:'🌞',tag:'BULK ENQUIRY'},
    {name:'Emergency Solar Lantern',category:'Solar Lanterns',description:'Confirm battery capacity, runtime and charging details.',price_paise:0,stock:0,image_url:'https://images.unsplash.com/photo-1504851149312-7a075b496cc7?auto=format&fit=crop&w=800&q=80',icon:'🔦',tag:'ASK FOR PRICE'},
    {name:'Solar Lighting Accessories',category:'Solar Accessories',description:'Accessories vary by model. Confirm compatibility and price before ordering.',price_paise:0,stock:0,image_url:'https://images.unsplash.com/photo-1585771724684-38269d6639fd?auto=format&fit=crop&w=800&q=80',icon:'🔌',tag:'ASK FOR PRICE'}
  ];
  const tx = db.transaction(rows => rows.forEach(p => insert.run(p)));
  tx(seed);
}

const adminUsername = process.env.ADMIN_USERNAME || 'admin';
const adminPassword = process.env.ADMIN_PASSWORD;
if (adminPassword) {
  const found = db.prepare('SELECT id FROM admins WHERE username = ?').get(adminUsername);
  if (!found) db.prepare('INSERT INTO admins(username,password_hash) VALUES(?,?)').run(adminUsername, bcrypt.hashSync(adminPassword, 12));
}

const razorpayReady = Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET && !process.env.RAZORPAY_KEY_ID.includes('replace'));
const razorpay = razorpayReady ? new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET }) : null;

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: 'draft-7', legacyHeaders: false }));

// Razorpay webhook needs the exact raw bytes for signature verification; mount before JSON parser.
app.post('/api/payments/razorpay-webhook', express.raw({ type: 'application/json' }), (req, res) => {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  const signature = req.get('x-razorpay-signature');
  if (!secret || !signature || !Buffer.isBuffer(req.body)) return res.status(400).send('Webhook not configured');
  const expected = crypto.createHmac('sha256', secret).update(req.body).digest('hex');
  if (!safeCompare(expected, signature)) return res.status(400).send('Invalid signature');
  let event;
  try { event = JSON.parse(req.body.toString('utf8')); } catch { return res.status(400).send('Invalid JSON'); }
  const eventId = req.get('x-razorpay-event-id') || `${event.event}:${event.payload?.payment?.entity?.id || event.payload?.order?.entity?.id || ''}`;
  try {
    const already = db.prepare('SELECT event_id FROM webhook_events WHERE event_id = ?').get(eventId);
    if (already) return res.status(200).json({ received: true, duplicate: true });
    db.prepare('INSERT INTO webhook_events(event_id) VALUES(?)').run(eventId);
    if (event.event === 'payment.captured' || event.event === 'order.paid') {
      const payment = event.payload?.payment?.entity;
      const rOrderId = payment?.order_id || event.payload?.order?.entity?.id;
      if (rOrderId) markPaidByRazorpayOrder(rOrderId, payment?.id || null);
    }
    if (event.event === 'payment.failed') {
      const payment = event.payload?.payment?.entity;
      if (payment?.order_id) db.prepare(`UPDATE orders SET payment_status='failed', updated_at=CURRENT_TIMESTAMP WHERE razorpay_order_id=? AND payment_status!='paid'`).run(payment.order_id);
    }
  } catch (err) { console.error('Webhook processing error:', err.message); return res.status(500).send('Webhook processing failed'); }
  return res.status(200).json({ received: true });
});

app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: false, limit: '20kb' }));
app.use(session({
  name: 'alkhair.sid',
  store: new SQLiteStore({ db: 'sessions.db', dir: DATA_DIR }),
  secret: process.env.SESSION_SECRET || 'development-only-change-this-secret-before-deploying',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'strict', secure: process.env.NODE_ENV === 'production', maxAge: 8 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(ROOT, 'public')));

function safeCompare(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const ba = Buffer.from(a); const bb = Buffer.from(b);
  return ba.length === bb.length && crypto.timingSafeEqual(ba, bb);
}
function isAdmin(req, res, next) {
  if (req.session && req.session.adminId) return next();
  return res.status(401).json({ error: 'Please sign in as an administrator.' });
}
function publicProduct(row) {
  return { id: row.id, name: row.name, category: row.category, specs: row.description, description: row.description,
    price: row.price_paise > 0 ? row.price_paise / 100 : null, stock: row.stock, image: row.image_url, icon: row.icon, tag: row.tag, inStock: row.stock > 0, active: Boolean(row.active) };
}
function makeOrderNo() { return 'AKS-' + new Date().toISOString().slice(2,10).replace(/-/g,'') + '-' + crypto.randomBytes(3).toString('hex').toUpperCase(); }
function makeTrackingCode() { return crypto.randomBytes(5).toString('hex').toUpperCase(); }
function markPaidByRazorpayOrder(razorpayOrderId, paymentId) {
  const order = db.prepare('SELECT * FROM orders WHERE razorpay_order_id=?').get(razorpayOrderId);
  if (!order || order.payment_status === 'paid') return;
  const items = JSON.parse(order.items_json);
  const transaction = db.transaction(() => {
    db.prepare(`UPDATE orders SET payment_status='paid', order_status='Confirmed', razorpay_payment_id=COALESCE(?,razorpay_payment_id), updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(paymentId, order.id);
    const decrement = db.prepare('UPDATE products SET stock=MAX(0,stock-?),updated_at=CURRENT_TIMESTAMP WHERE id=?');
    items.forEach(item => decrement.run(item.qty, item.id));
  });
  transaction();
}

app.get('/api/config', (req, res) => res.json({ razorpayKeyId: razorpayReady ? process.env.RAZORPAY_KEY_ID : null, paymentsEnabled: razorpayReady, businessName: 'Al Khair Solar Energy' }));
app.get('/api/products', (req, res) => {
  const rows = db.prepare('SELECT * FROM products WHERE active=1 ORDER BY id DESC').all();
  res.json(rows.map(publicProduct));
});

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, message: { error: 'Too many sign-in attempts. Try again later.' }, standardHeaders: 'draft-7', legacyHeaders: false });
app.post('/api/admin/login', authLimiter, (req, res, next) => {
  const { username, password } = req.body || {};
  if (typeof username !== 'string' || typeof password !== 'string') return res.status(400).json({ error: 'Enter username and password.' });
  const admin = db.prepare('SELECT * FROM admins WHERE username=?').get(username.trim());
  if (!admin || !bcrypt.compareSync(password, admin.password_hash)) return res.status(401).json({ error: 'Incorrect username or password.' });
  req.session.regenerate(err => {
    if (err) return next(err);
    req.session.adminId = admin.id;
    req.session.adminUsername = admin.username;
    req.session.save(err2 => err2 ? next(err2) : res.json({ ok: true, username: admin.username }));
  });
});
app.get('/api/admin/me', isAdmin, (req, res) => res.json({ username: req.session.adminUsername }));
app.post('/api/admin/logout', isAdmin, (req, res) => req.session.destroy(() => res.clearCookie('alkhair.sid').json({ ok: true })));

app.get('/api/admin/products', isAdmin, (req, res) => res.json(db.prepare('SELECT * FROM products ORDER BY id DESC').all().map(p => ({ ...publicProduct(p), price: p.price_paise / 100, pricePaise: p.price_paise, active: Boolean(p.active) }))));
app.post('/api/admin/products', isAdmin, (req, res) => {
  const v = validateProduct(req.body);
  if (v.error) return res.status(400).json({ error: v.error });
  const info = db.prepare(`INSERT INTO products(name,category,description,price_paise,stock,image_url,icon,tag,active) VALUES(@name,@category,@description,@price_paise,@stock,@image_url,@icon,@tag,@active)`).run(v.value);
  res.status(201).json(publicProduct(db.prepare('SELECT * FROM products WHERE id=?').get(info.lastInsertRowid)));
});
app.put('/api/admin/products/:id', isAdmin, (req, res) => {
  const id = Number(req.params.id); if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: 'Invalid product ID.' });
  if (!db.prepare('SELECT id FROM products WHERE id=?').get(id)) return res.status(404).json({ error: 'Product not found.' });
  const v = validateProduct(req.body); if (v.error) return res.status(400).json({ error: v.error });
  db.prepare(`UPDATE products SET name=@name,category=@category,description=@description,price_paise=@price_paise,stock=@stock,image_url=@image_url,icon=@icon,tag=@tag,active=@active,updated_at=CURRENT_TIMESTAMP WHERE id=@id`).run({ ...v.value, id });
  res.json(publicProduct(db.prepare('SELECT * FROM products WHERE id=?').get(id)));
});
app.delete('/api/admin/products/:id', isAdmin, (req, res) => {
  const id = Number(req.params.id); if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: 'Invalid product ID.' });
  const info = db.prepare('UPDATE products SET active=0,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(id);
  if (!info.changes) return res.status(404).json({ error: 'Product not found.' });
  res.json({ ok: true });
});
function validateProduct(body) {
  const b = body || {};
  const name = String(b.name || '').trim(); const category = String(b.category || '').trim();
  const description = String(b.description ?? b.specs ?? '').trim(); const image_url = String(b.image_url ?? b.image ?? '').trim();
  const icon = String(b.icon || '💡').trim().slice(0,12); const tag = String(b.tag || '').trim().slice(0,40);
  const price = Number(b.price); const stock = Number(b.stock);
  if (!name || name.length > 120 || !category || category.length > 80) return { error: 'Product name and category are required (max 120/80 characters).' };
  if (!Number.isFinite(price) || price < 0 || price > 10000000) return { error: 'Price must be between ₹0 and ₹1 crore.' };
  if (!Number.isInteger(stock) || stock < 0 || stock > 1000000) return { error: 'Stock must be a whole number from 0 to 1,000,000.' };
  if (description.length > 2000 || image_url.length > 1000) return { error: 'Description or image URL is too long.' };
  if (image_url && !/^https:\/\//i.test(image_url)) return { error: 'Product image must use an https:// URL.' };
  return { value: { name, category, description, price_paise: Math.round(price * 100), stock, image_url, icon, tag, active: b.active === false || b.active === 0 ? 0 : 1 } };
}

app.post('/api/checkout/create', async (req, res) => {
  if (!razorpayReady) return res.status(503).json({ error: 'Online payments are not configured yet. Add your Razorpay TEST keys to the server .env file.' });
  const { customer = {}, items = [] } = req.body || {};
  const name = String(customer.name || '').trim(); const phone = String(customer.phone || '').replace(/[\s()-]/g,'');
  const email = String(customer.email || '').trim(); const address = String(customer.address || '').trim(); const pincode = String(customer.pincode || '').trim();
  if (name.length < 2 || name.length > 100 || !/^\+?[0-9]{10,13}$/.test(phone) || address.length < 8 || address.length > 500 || !/^[0-9]{6}$/.test(pincode) || (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))) return res.status(400).json({ error: 'Please enter a valid name, phone, delivery address and 6-digit PIN code. Email is optional.' });
  if (!Array.isArray(items) || items.length < 1 || items.length > 30) return res.status(400).json({ error: 'Your cart is empty or contains too many different products.' });
  const normalized = [];
  const getProduct = db.prepare('SELECT * FROM products WHERE id=? AND active=1');
  for (const item of items) {
    const id = Number(item.id); const qty = Number(item.qty);
    if (!Number.isInteger(id) || !Number.isInteger(qty) || qty < 1 || qty > 100) return res.status(400).json({ error: 'Invalid item quantity.' });
    const p = getProduct.get(id);
    if (!p || p.price_paise <= 0) return res.status(400).json({ error: 'One or more products need a quotation and cannot be paid online.' });
    if (p.stock < qty) return res.status(409).json({ error: `${p.name} has only ${p.stock} item(s) in stock.` });
    normalized.push({ id: p.id, name: p.name, price: p.price_paise / 100, price_paise: p.price_paise, qty, line_total_paise: p.price_paise * qty });
  }
  const totalPaise = normalized.reduce((sum, item) => sum + item.line_total_paise, 0);
  if (totalPaise < 100 || totalPaise > 50000000) return res.status(400).json({ error: 'Order total must be between ₹1 and ₹5,00,000.' });
  const orderNo = makeOrderNo(); const trackingCode = makeTrackingCode();
  let internalId;
  try {
    const info = db.prepare(`INSERT INTO orders(order_no,tracking_code,customer_name,phone,email,address,pincode,items_json,total_paise) VALUES(?,?,?,?,?,?,?,?,?)`)
      .run(orderNo, trackingCode, name, phone, email, address, pincode, JSON.stringify(normalized), totalPaise);
    internalId = info.lastInsertRowid;
    const rpOrder = await razorpay.orders.create({ amount: totalPaise, currency: 'INR', receipt: orderNo, notes: { store_order_no: orderNo, tracking_code: trackingCode } });
    db.prepare('UPDATE orders SET razorpay_order_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(rpOrder.id, internalId);
    res.status(201).json({ orderNo, trackingCode, total: totalPaise / 100, razorpayOrderId: rpOrder.id, amount: rpOrder.amount, currency: rpOrder.currency, keyId: process.env.RAZORPAY_KEY_ID, customerName: name, customerEmail: email, customerPhone: phone });
  } catch (err) {
    if (internalId) db.prepare('DELETE FROM orders WHERE id=? AND payment_status="created"').run(internalId);
    console.error('Checkout create error:', err.message);
    res.status(502).json({ error: 'Could not start payment. Please retry in a moment.' });
  }
});

app.post('/api/checkout/verify', async (req, res) => {
  if (!razorpayReady) return res.status(503).json({ error: 'Payments are not configured.' });
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature, orderNo } = req.body || {};
  if (![razorpay_order_id, razorpay_payment_id, razorpay_signature, orderNo].every(v => typeof v === 'string' && v.length < 200)) return res.status(400).json({ error: 'Missing payment verification details.' });
  const order = db.prepare('SELECT * FROM orders WHERE order_no=? AND razorpay_order_id=?').get(orderNo, razorpay_order_id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  const expected = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET).update(`${order.razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
  if (!safeCompare(expected, razorpay_signature)) return res.status(400).json({ error: 'Payment signature could not be verified. Contact support before retrying.' });
  try {
    const payment = await razorpay.payments.fetch(razorpay_payment_id);
    if (payment.order_id !== order.razorpay_order_id || Number(payment.amount) !== order.total_paise || payment.currency !== 'INR') return res.status(400).json({ error: 'Payment details do not match this order. Please contact the store.' });
    if (payment.status !== 'captured') return res.status(409).json({ error: 'Payment is not captured yet. Please wait a moment and check order tracking.' });
    markPaidByRazorpayOrder(razorpay_order_id, razorpay_payment_id);
    return res.json({ ok: true, orderNo: order.order_no, trackingCode: order.tracking_code, paymentStatus: 'paid', orderStatus: 'Confirmed' });
  } catch (err) {
    console.error('Payment verification fetch error:', err.message);
    return res.status(502).json({ error: 'Could not confirm payment status with Razorpay. Please check your order status before retrying payment.' });
  }
});

app.post('/api/orders/track', (req, res) => {
  const orderNo = String(req.body?.orderNo || '').trim().toUpperCase();
  const phone = String(req.body?.phone || '').replace(/[\s()-]/g,'');
  if (!orderNo || !phone) return res.status(400).json({ error: 'Enter your order number and phone number.' });
  const order = db.prepare('SELECT order_no,tracking_code,customer_name,phone,items_json,total_paise,payment_status,order_status,created_at,updated_at FROM orders WHERE order_no=?').get(orderNo);
  if (!order || !safeCompare(order.phone, phone)) return res.status(404).json({ error: 'No matching order was found. Check the order number and phone number.' });
  res.json({ orderNo: order.order_no, trackingCode: order.tracking_code, customerName: order.customer_name, items: JSON.parse(order.items_json).map(i=>({name:i.name,qty:i.qty})), total: order.total_paise/100, paymentStatus: order.payment_status, orderStatus: order.order_status, createdAt: order.created_at, updatedAt: order.updated_at });
});

app.get('/api/admin/orders', isAdmin, (req, res) => {
  const rows = db.prepare('SELECT * FROM orders ORDER BY id DESC LIMIT 500').all();
  res.json(rows.map(o => ({ id:o.id, orderNo:o.order_no, trackingCode:o.tracking_code, customerName:o.customer_name, phone:o.phone, email:o.email, address:o.address, pincode:o.pincode, items:JSON.parse(o.items_json), total:o.total_paise/100, paymentStatus:o.payment_status, orderStatus:o.order_status, createdAt:o.created_at, updatedAt:o.updated_at, paymentId:o.razorpay_payment_id })));
});
app.patch('/api/admin/orders/:id/status', isAdmin, (req, res) => {
  const id = Number(req.params.id); const status = String(req.body?.status || '');
  const allowed = ['Confirmed','Processing','Packed','Shipped','Out for delivery','Delivered','Cancelled'];
  if (!Number.isInteger(id) || !allowed.includes(status)) return res.status(400).json({ error: 'Invalid order or status.' });
  const order = db.prepare('SELECT payment_status FROM orders WHERE id=?').get(id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  if (status !== 'Cancelled' && order.payment_status !== 'paid') return res.status(409).json({ error: 'Only paid orders can be moved through fulfilment.' });
  db.prepare('UPDATE orders SET order_status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status,id);
  res.json({ ok:true });
});

app.get('/health', (req,res)=>res.json({ok:true, service:'Al Khair Solar Energy'}));
app.get('/admin', (req,res)=>res.sendFile(path.join(ROOT,'public','admin.html')));
app.get('/track', (req,res)=>res.sendFile(path.join(ROOT,'public','index.html')));
app.get('*', (req,res,next)=>{
  if (req.path.startsWith('/api/')) return res.status(404).json({error:'API route not found.'});
  res.sendFile(path.join(ROOT,'public','index.html'), err => err && next(err));
});
app.use((err,req,res,next)=>{ console.error(err); if(res.headersSent)return next(err); res.status(500).json({error:'Unexpected server error.'}); });

app.listen(PORT, () => {
  console.log(`Al Khair Solar Energy is running on port ${PORT}`);
  if (!adminPassword) console.warn('ADMIN_PASSWORD is not set: admin login will not be created. Configure .env before using /admin.');
  if (!razorpayReady) console.warn('Razorpay keys are not configured: online checkout is disabled until .env is configured.');
});
